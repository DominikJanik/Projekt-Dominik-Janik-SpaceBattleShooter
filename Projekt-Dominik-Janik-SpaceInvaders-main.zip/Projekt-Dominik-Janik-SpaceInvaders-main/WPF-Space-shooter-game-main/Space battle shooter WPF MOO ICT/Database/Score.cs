﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_battle_shooter_WPF_MOO_ICT.Database
{
    public class Score
    {
        public int Id { get; set; }
        public int Points { get; set; }
        public string Nick { get; set; }
    }
}
