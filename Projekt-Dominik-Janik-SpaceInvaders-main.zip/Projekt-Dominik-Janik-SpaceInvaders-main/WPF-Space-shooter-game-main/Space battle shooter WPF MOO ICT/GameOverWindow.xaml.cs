﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Space_battle_shooter_WPF_MOO_ICT.Database;

namespace Space_battle_shooter_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for GameOverWindow.xaml
    /// </summary>
    public partial class GameOverWindow : Window
    {
        private readonly SpaceShooterDbContext _dbContext;
        private int _score;

        public GameOverWindow(int score, SpaceShooterDbContext dbContext)
        {
            InitializeComponent();
            _score = score;
            ScoreTextBlock.Text = score.ToString();
            _dbContext = dbContext;
            var scoresList = new List<Score>();
            scoresList = dbContext.Scores.ToList();
            HighscoresListView.ItemsSource = scoresList.OrderByDescending(s => s.Points);
        }

        private void OkButton_OnClick(object sender, RoutedEventArgs e)
        {
            _dbContext.Add(new Score() {Nick = NicknameTextBox.Text, Points = _score});
            _dbContext.SaveChanges();
            Close();
        }
    }
}
